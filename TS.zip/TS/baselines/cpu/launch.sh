./streamp_openmp inputs/randomlist33M.txt 256
