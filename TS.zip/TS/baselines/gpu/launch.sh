./STREAMP 256 inputs/randomlist33M.txt /dev/null 
