/* Communication with a DPU via the MRAM. */
/* Populate the MRAM with a collection of bytes and request the DPU to */
/* compute the checksum. */

#include <dpu.h>
#include <dpu_log.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
// #include "common.h"
#include "timer.h"
#include "params.h"
#include "tools.h"

// #if ENERGY
//#include <dpu_probe.h>
// #endif

#ifndef DPU_BINARY
#define DPU_BINARY "cs_dpu"
#endif


DTYPE ts_size;
DTYPE tSeries[1 << 21]; //max capacity 64M DTYPE
DTYPE AMean[1 << 21];
DTYPE ASigma[1 << 21];




int main(int argc, char **argv) {
	// Timer declaration
	Timer timer;
	int rep = 1;
	int timer_rep = rep - 1;
	struct Params p = input_params(argc, argv);
// #if ENERGY
// 	struct dpu_probe_t probe;
// 	DPU_ASSERT(dpu_probe_init("energy_probe", &probe));
// #endif

    struct dpu_set_t set, dpu;
    DTYPE checksum;
	DTYPE  idback[16];
	DTYPE nr_of_dpus;

    DPU_ASSERT(dpu_alloc(NR_DPUS, NULL, &set));
    DPU_ASSERT(dpu_load(set, DPU_BINARY, NULL));
  	DPU_ASSERT(dpu_get_nr_dpus(set, &nr_of_dpus));//得到dpu的数目
    printf("number of DPUs : %d\n",nr_of_dpus);

    const char *infilename = p.input_path;
	const DTYPE query_length = p.input_size_m;

	//caculate the time to prepare the time
	start(&timer, 1, timer_rep);
	//const char *infilename = "./inputs/randomSerie1k.txt";
    DTYPE *status = read_test_file(infilename, &ts_size,tSeries);
    if (status == NULL) {
        printf("Error opening file.\n");
        return 1;
    }


	//DTYPE query_length = 64;
  	//ts_size = ts_size +  (nr_of_dpus * 16 * query_length - ts_size % (nr_of_dpus * 16 * query_length));
	//if we use the query=64 nr_tasklet = 16 so we first test NR_DPU = 1024
	
	DTYPE profilelength = ts_size - query_length;
	
	preprocess_ts(AMean,ASigma,tSeries, ts_size, profilelength, query_length);
	
	DTYPE* diags = malloc(sizeof(DTYPE) * profilelength);
	for(int i = 0; i < profilelength; i++){
		diags[i] = i + 1 ;
	}
	
	shuffle(diags,profilelength);

	DTYPE diags_per_dpu = profilelength / nr_of_dpus;
	// DTYPE diags_per_dpu = 12;

	printf("ts_size : %d\n",ts_size);
	printf("query : %d\n",query_length);
	printf("profilelength : %d\n",profilelength);
    printf("diags per dpu : %d\n",diags_per_dpu);

	// printf("here we send data in\n");
	// for (size_t i = 0; i < ts_size; i++)
	// {
	// 	printf("%d   ", tSeries[i]);
	// }
	dpu_result_t* result = malloc(sizeof(dpu_result_t) * profilelength);
	for (int j = 0; j < profilelength - 1; j++) {
        result[j].minValue = INT32_MAX;
        result[j].minIndex = 0;
    }


	stop(&timer, 1);

	start(&timer, 2, timer_rep);
	DPU_FOREACH(set, dpu) {
		dpu_arguments_t input_arguments = {ts_size, query_length, diags_per_dpu};//单核一人全做

		DPU_ASSERT(dpu_copy_to(dpu, "DPU_INPUT_ARGUMENTS", 0, (const void *) &input_arguments, sizeof(input_arguments)));
	}

	DPU_ASSERT(dpu_broadcast_to(set, "TS",    0, tSeries, sizeof(DTYPE) * ts_size, DPU_XFER_DEFAULT));
	DPU_ASSERT(dpu_broadcast_to(set, "Mean",  0, AMean, sizeof(DTYPE) * ts_size, DPU_XFER_DEFAULT));
	DPU_ASSERT(dpu_broadcast_to(set, "Sigma", 0, ASigma, sizeof(DTYPE) * ts_size, DPU_XFER_DEFAULT));	
	
	uint32_t i = 0;
	DPU_FOREACH(set, dpu, i) {
	 	DPU_ASSERT(dpu_prepare_xfer(dpu, &diags[i * diags_per_dpu]));
	}
	DPU_ASSERT(dpu_push_xfer(set, DPU_XFER_TO_DPU, "diags", 0, diags_per_dpu * sizeof(DTYPE), DPU_XFER_DEFAULT));
	
	stop(&timer, 2);

// #if ENERGY 			
// 	DPU_ASSERT(dpu_probe_start(&probe));
// #endif

	//calculate the time for dpu processing
	start(&timer, 3, timer_rep);
	DPU_ASSERT(dpu_launch(set, DPU_SYNCHRONOUS));
	stop(&timer, 3);

// #if ENERGY
// 			DPU_ASSERT(dpu_probe_stop(&probe));
// #endif

	printf("printing log for dpu:\n");
		DPU_FOREACH(set, dpu) {
    DPU_ASSERT(dpu_log_read(dpu, stdout));
  }

// #if ENERGY
// 	double acc_energy, avg_energy, acc_time, avg_time;
// 	DPU_ASSERT(dpu_probe_get(&probe, DPU_ENERGY, DPU_ACCUMULATE, &acc_energy));
// 	DPU_ASSERT(dpu_probe_get(&probe, DPU_ENERGY, DPU_AVERAGE, &avg_energy));
// 	DPU_ASSERT(dpu_probe_get(&probe, DPU_TIME, DPU_ACCUMULATE, &acc_time));
// 	DPU_ASSERT(dpu_probe_get(&probe, DPU_TIME, DPU_AVERAGE, &avg_time));
// 	printf("Energy (J): %f J\t", avg_energy);
// 	DPU_ASSERT(dpu_probe_deinit(&probe));
// #endif
	
	// 每个dpu给tasklet都mollc一个profile作为部分结果
	DTYPE* results_val[nr_of_dpus];
	DTYPE* results_idx[nr_of_dpus];

	for(int j = 0; j < nr_of_dpus; j++){
		results_val[j] = (DTYPE*) malloc(profilelength * sizeof(DTYPE));
		results_idx[j] = (DTYPE*) malloc(profilelength * sizeof(DTYPE));
		}

	//calculate the time for dpu transfer back
	start(&timer, 4, timer_rep);

	// //use the parallel transfer to transfer the parital result back to host
	DPU_FOREACH(set, dpu, i) {
		DPU_ASSERT(dpu_prepare_xfer(dpu, results_val[i]));
		}
	DPU_ASSERT(dpu_push_xfer(set, DPU_XFER_FROM_DPU, "result_minValue", 0, profilelength * sizeof(DTYPE), DPU_XFER_DEFAULT));

	DPU_FOREACH(set, dpu, i) {
	DPU_ASSERT(dpu_prepare_xfer(dpu, results_idx[i]));
		}
	DPU_ASSERT(dpu_push_xfer(set, DPU_XFER_FROM_DPU, "result_minIndex", 0, profilelength * sizeof(DTYPE), DPU_XFER_DEFAULT));

	DPU_FOREACH(set, dpu) {
    DPU_ASSERT(dpu_copy_from(dpu, "id", 0, (DTYPE *)idback, sizeof(DTYPE)*16));
  }
  	stop(&timer,4);

	printf("here we get res back\n");
	for (uint32_t i = 0; i < 10; i++)
	{
		printf("%d   ID %d    dis: %d  \n",i,results_idx[0][i] ,results_val[0][i]);
	}

	//遍历所有dpu的所有结果,得到最后的结果
	for(int dpu_cnt=0; dpu_cnt < nr_of_dpus; dpu_cnt++) {
		for (unsigned int each_idx = 0; each_idx < profilelength; each_idx++) {
			if(results_val[dpu_cnt][each_idx] < result[each_idx].minValue && results_val[dpu_cnt][each_idx] >= 0){
				result[each_idx].minValue = results_val[dpu_cnt][each_idx];
				result[each_idx].minIndex = results_idx[dpu_cnt][each_idx];
			}
			else
				result[each_idx].minValue = 0;
			}
			free(results_val[dpu_cnt]);
		}
	


	const char *outfile = "result.txt";
    DTYPE outstatus = save_result_file(outfile, profilelength, result);
    if (outstatus == 0) {
        printf("Error opening file.\n");
        return 1;
	}

	printf("\nhere we get id back\n");
	for (size_t i = 0; i < 16; i++)
	{
		printf("%d   ", idback[i]);
	}

  DPU_ASSERT(dpu_free(set));

	printf("\n--------- Time of different stages -----------\n");
	printf("Data Prepare Time (ms): ");
	print(&timer, 1, rep);
	printf("CPU-DPU Time (ms): ");
	print(&timer, 2, rep);
	printf("DPU Kernel Time (ms): ");
	print(&timer, 3, rep);
	printf("DPU-CPU Time (ms): ");
	print(&timer, 4, rep);
  
  free(diags);
  return 0;
}


// 		DPU_FOREACH(set, dpu) {
// 		DPU_ASSERT(dpu_copy_from(dpu, "checksum", 0, (uint32_t *)&checksum, sizeof(checksum)));
//     	printf("Computed sum = %d\n", checksum);
//   }

// 	DPU_FOREACH(set, dpu) {
//     DPU_ASSERT(dpu_copy_from(dpu, "input_readback", 0, (uint32_t *)readback, sizeof(DTYPE)*ts_size));
//   }
	
// 	DPU_FOREACH(set, dpu) {
//     DPU_ASSERT(dpu_copy_from(dpu, "diag_readback", 0, (uint32_t *)diagback, sizeof(DTYPE)*BUFFER_SIZE));
//   }
  
// 	DPU_FOREACH(set, dpu) {
//     DPU_ASSERT(dpu_copy_from(dpu, "id", 0, (uint32_t *)idback, sizeof(DTYPE)*16));
//   }

	// printf("here we get data back\n");
	// for (size_t i = 0; i < ts_size; i++)
	// {
	// 	printf("%d   ", readback[i]);
	// }


	// printf("\nhere we get diag back\n");
	// for (size_t i = 0; i < 200; i++)
	// {
	// 	printf("%d   ", diagback[i]);
	// }

	// printf("\nhere we get id back\n");
	// for (size_t i = 0; i < 16; i++)
	// {
	// 	printf("%d   ", idback[i]);
	// }