#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include "common.h"

int32_t *read_test_file(const char *infilename, unsigned int *ts_size, DTYPE* tSeries) {
	FILE *TimeSeriesFile;
    TimeSeriesFile = fopen(infilename,"r");
	 if (TimeSeriesFile == NULL){ 
	 	return NULL;
	 }
	double temp;
	int32_t len = 0;
	while(fscanf(TimeSeriesFile,"%lf",&temp) == 1){
        // printf("%lf",temp);
		//tSeries[len] = temp/100;
		tSeries[len] = temp *1000;
		len++;
	}
	*ts_size = len;
	fclose(TimeSeriesFile);
	return tSeries;
}



int32_t save_result_file(const char *outfilename, DTYPE profilelength, dpu_result_t *out_result) {
	FILE *OutFile;
    OutFile = fopen(outfilename,"w");
	
	if (OutFile == NULL){ 
	 	return 0;
	}
    
	for (int i = 0; i < profilelength; i++) {
        fprintf(OutFile, "%f\n", (double)(out_result[i].minValue));
    }

	fclose(OutFile);
	return 1;
}

void shuffle(int* nums, int numsSize) {
    // 初始化随机数生成器
    srand(0);
    // 随机交换数组元素
    for (int i = 0; i < numsSize; i++) {
        int j = i + rand() % (numsSize - i);
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}



void preprocess_ts(DTYPE* AMean, DTYPE* ASigma, DTYPE* tSeries,unsigned int timeSeriesLength, unsigned int ProfileLength, unsigned int queryLength)
{
	double* ACumSum = malloc(sizeof(double) * timeSeriesLength);
	double* ASqCumSum = malloc(sizeof(double) * timeSeriesLength);
	double* ASum = malloc(sizeof(double) * ProfileLength);
	double* ASumSq = malloc(sizeof(double) * ProfileLength);
	double* ASigmaSq = malloc(sizeof(double) * ProfileLength);
	double* AMean_tmp = malloc(sizeof(double) * ProfileLength);

	for(int jj =0; jj<queryLength;jj++)
		printf("%d   ",tSeries[jj]);

	ACumSum[0] = tSeries[0];
	ASqCumSum[0] = tSeries[0] * tSeries[0];

	for (int32_t i = 1; i < timeSeriesLength; i++){
		ACumSum[i] = tSeries[i] + ACumSum[i - 1];
		ASqCumSum[i] = tSeries[i] * tSeries[i] + ASqCumSum[i - 1];
		}

	ASum[0] = ACumSum[queryLength - 1];
	ASumSq[0] = ASqCumSum[queryLength - 1];
	printf("\nAsumsq[0] %f\n",ASumSq[0]);
	
	for (int i = 0; i < timeSeriesLength - queryLength; i++){
		ASum[i + 1] = ACumSum[queryLength + i] - ACumSum[i];
		ASumSq[i + 1] = ASqCumSum[queryLength + i] - ASqCumSum[i];
	}

	for (int i = 0; i < ProfileLength; i++){
		AMean_tmp[i] = ASum[i] / queryLength;
	}

	//fix error here the std is wrong now it is correct
	for (int i = 0; i < ProfileLength; i++){
		ASigmaSq[i] = ASumSq[i] / queryLength - AMean_tmp[i] * AMean_tmp[i];
	}	
		printf("AMeantmp[0] %f\n",AMean_tmp[0]);
			
	for (int i = 0; i < ProfileLength; i++)
	{
		ASigma[i] = (DTYPE)(sqrt(ASigmaSq[i])*10);
		AMean[i]  = (DTYPE) (AMean_tmp[i]*10);
	}
		printf("Asigma[0]%d\n",ASigma[0]);

	free(ACumSum);
	free(ASqCumSum);
	free(ASum);
	free(ASumSq);
	free(ASigmaSq);
	free(AMean_tmp);
}


