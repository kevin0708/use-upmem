#ifndef TOOLS__H
#define TOOLS__H

int32_t *read_test_file(const char *infilename, unsigned int *ts_size, DTYPE* tSeries);
int32_t save_result_file(const char *outfilename, DTYPE profilelength, dpu_result_t *out_result);
void shuffle(int* nums, int numsSize) ;
void preprocess_ts(DTYPE* AMean, DTYPE* ASigma, DTYPE* tSeries,unsigned int timeSeriesLength, unsigned int ProfileLength, unsigned int queryLength);

#endif