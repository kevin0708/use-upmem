#ifndef _COMMON_H_
#define _COMMON_H_

// Transfer size between MRAM and WRAM
// #ifdef BL
// #define BLOCK_SIZE_LOG2 BL
// #define BLOCK_SIZE (1 << BLOCK_SIZE_LOG2)
// #else
// #define BLOCK_SIZE_LOG2 8
// #define BLOCK_SIZE (1 << BLOCK_SIZE_LOG2) //transfer size 是 2^8=256byte
// #endif

// Data type
#define DTYPE int32_t
#define DTYPE_MAX INT32_MAX

typedef struct  {
	uint32_t ts_length;
    uint32_t query_length;
    uint32_t slice_per_dpu;
    //int32_t exclusion_zone;
}dpu_arguments_t;

typedef struct  {
    DTYPE minValue;
    uint32_t minIndex;
    // DTYPE maxValue;
    // uint32_t maxIndex;
}dpu_result_t;

typedef struct  {
    dpu_result_t* min;
}dpu_profile_t;

typedef struct  {
    int start;  // 子任务块的起始位置
    int end;    // 子任务块的结束位置
    int diag;   // 原始任务大小
}dpu_task;

#ifndef ENERGY
#define ENERGY 0
#endif
#define PRINT 0 

#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_RESET   "\x1b[0m"
#endif
