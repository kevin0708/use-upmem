#include <mram.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <alloc.h>
#include <barrier.h>
#include <defs.h>
#include "common.h"
#include <perfcounter.h>

#define CACHE_SIZE 64
#define ELEM_IN_BLOCK 64

#define BUFFER_SIZE (1 << 21)
#define DIAG_SIZE (1 << 12)
__mram_noinit DTYPE TS[BUFFER_SIZE];
__mram_noinit DTYPE Mean[BUFFER_SIZE];
__mram_noinit DTYPE Sigma[BUFFER_SIZE];
__host DTYPE diags[DIAG_SIZE];
// __mram_noinit DTYPE diags[DIAG_SIZE];

__host DTYPE id[16];

__host dpu_arguments_t DPU_INPUT_ARGUMENTS;
__host DTYPE cache_diag_block[CACHE_SIZE];

__mram_noinit DTYPE result_minValue[BUFFER_SIZE];
__mram_noinit DTYPE result_minIndex[BUFFER_SIZE];

__host uint64_t dataread[NR_TASKLETS];
__host uint64_t calcuQ[NR_TASKLETS];
__host uint64_t calcuD[NR_TASKLETS];
__host uint64_t memsave[NR_TASKLETS];
__host uint64_t total[NR_TASKLETS];

static int min(int a, int b){
	if(a > b) return b;
	else return a;
} 


static DTYPE calculate_Q(DTYPE row, DTYPE col, DTYPE query_length, DTYPE* cache_block_row1, DTYPE* cache_block_col1) {
	DTYPE result;
	DTYPE cache_block_row[ELEM_IN_BLOCK+2];
	DTYPE cache_block_col[ELEM_IN_BLOCK+2];
	for(uint32_t blk_cnt = 0; blk_cnt < query_length ; blk_cnt += ELEM_IN_BLOCK)
	{
		mram_read(&TS[row + blk_cnt], cache_block_row, (ELEM_IN_BLOCK +2) *sizeof(DTYPE));//row 在这里发挥功效
		mram_read(&TS[col + blk_cnt], cache_block_col, (ELEM_IN_BLOCK +2) *sizeof(DTYPE));//col在这里发挥功效
		DTYPE bound = min(query_length , ELEM_IN_BLOCK);
        //DTYPE bound = query_length;
		DTYPE row_odd = row%2;
		DTYPE col_odd = col%2;
		for(uint32_t i = 0; i < bound; i++){
			result += cache_block_row[i + row_odd] * cache_block_col[i + col_odd];
		}
	 }
	return result;
}


void scrimp(DTYPE tasklet_id,DTYPE profilelength , DTYPE current_diag ,DTYPE query_length){
		
		//select a diagonal	
		DTYPE distance = 0;

		//used for dot prod
		DTYPE cache_Q[ELEM_IN_BLOCK];
		
		//used for successive Q calculation 
		DTYPE cache_TS_block[ELEM_IN_BLOCK +2];
		DTYPE cache_query_block[ELEM_IN_BLOCK +2];
		
		DTYPE cache_TS_next_block[ELEM_IN_BLOCK +2];
		DTYPE cache_query_next_block[ELEM_IN_BLOCK +2];
		
		//used for coresponding std and mean
		DTYPE cache_TS_mean_block[ELEM_IN_BLOCK +2];
		DTYPE cache_TS_std_block[ELEM_IN_BLOCK +2];

		DTYPE cache_query_mean_block[ELEM_IN_BLOCK +2];
		DTYPE cache_query_std_block[ELEM_IN_BLOCK +2];

		__dma_aligned DTYPE cache_my_val_block    [ELEM_IN_BLOCK +2];
		__dma_aligned DTYPE cache_my_idx_block    [ELEM_IN_BLOCK +2];

		//__dma_aligned dpu_result_t cache_mram_result_block[ELEM_IN_BLOCK];
		__dma_aligned DTYPE cache_mram_val_block  [ELEM_IN_BLOCK +2];
		__dma_aligned DTYPE cache_mram_idx_block  [ELEM_IN_BLOCK +2];

		DTYPE cache_last_ts1      = 0;
		DTYPE cache_last_ts2      = 0;
		DTYPE cache_last_ts_next1 = 0;
		DTYPE cache_last_ts_next2 = 0;
		DTYPE cache_last_Q        = 0;

		
		//防止第一次就不够，对着没有赋值的算dotproduct
		for(int i = 0; i < ELEM_IN_BLOCK + 2; i++){
			cache_TS_block[i] = 0;
			cache_query_block[i] = 0;
		}

		//分一下起始-结束
		//每个DPU都负责一个Diag，每个tasklet再均分处理一部分
		DTYPE slice = (profilelength - current_diag) / NR_TASKLETS;
		slice = slice - slice % 2;
		// slice = (slice % 2 == 0)? slice : slice - 1;
		DTYPE mystart = tasklet_id * slice;
		DTYPE myend   = mystart + slice;

		//TODO:profilelength 是规整过的，满足对齐的要求，但是减了i就不一定了
		//计算
		
		for(uint32_t i = mystart; i < myend; i+= ELEM_IN_BLOCK){
			DTYPE row = i;
			DTYPE col = i + current_diag;
			DTYPE rest_elem = (myend - i) ;
			DTYPE bound = min(rest_elem, ELEM_IN_BLOCK);
			DTYPE memo_bound = ELEM_IN_BLOCK + 2; //change here, no need to bound read
			DTYPE scale_query = 10*query_length;

			perfcounter_t point1 = perfcounter_get();
			mram_read(&TS[row], cache_TS_block,    sizeof(DTYPE) * memo_bound);
			mram_read(&TS[col], cache_query_block, sizeof(DTYPE) * memo_bound);

			mram_read(&TS[row + query_length], cache_TS_next_block   , sizeof(DTYPE) * memo_bound);
			mram_read(&TS[col + query_length], cache_query_next_block, sizeof(DTYPE) * memo_bound);
				
			mram_read(&Mean[row], cache_TS_mean_block, sizeof(DTYPE) * memo_bound);
			mram_read(&Mean[col], cache_query_mean_block,  sizeof(DTYPE) * memo_bound);
				
			mram_read(&Sigma[row] , cache_TS_std_block,  sizeof(DTYPE) * memo_bound);
			mram_read(&Sigma[col], cache_query_std_block, sizeof(DTYPE) * memo_bound);

			perfcounter_t point2 = perfcounter_get();
			dataread[tasklet_id] += point2-point1;

			DTYPE row_odd = row%2;
			DTYPE col_odd = col%2;
			
			for (uint32_t k = 0; k < bound; k++){
			 	if(k == 0){
					if(i == mystart) 
			 			cache_Q[k] = calculate_Q(row, col, query_length ,cache_TS_block ,cache_query_block);//每个block第一个用dotproduct算
					else 
						cache_Q[k] = cache_last_Q - cache_last_ts1 * cache_last_ts2 + cache_last_ts_next1 * cache_last_ts_next2;
				}
				else{
			 		cache_Q[k] = cache_Q[k-1] - (cache_TS_block[k - 1 + row_odd] * cache_query_block[k - 1 + col_odd]) + (cache_TS_next_block[k - 1 + row_odd] * cache_query_next_block[k - 1+ col_odd]);//后面的都用递推的办法
				}
                

				if(k == bound -1){
				cache_last_Q = cache_Q[k];
				cache_last_ts1 = cache_TS_block[k + row_odd];
				cache_last_ts2 = cache_query_block[k + col_odd];
				cache_last_ts_next1 = cache_TS_next_block[k + row_odd];
				cache_last_ts_next2 = cache_query_next_block[k + col_odd];
				}
			}

			perfcounter_t point3 = perfcounter_get();
			calcuQ[tasklet_id] += point3-point2;

			for (uint32_t k = 0; k < bound; k++){
				// DTYPE part1 = 100*cache_Q[k] - (query_length * cache_TS_mean_block[k + row_odd] * cache_query_mean_block[k + col_odd]);
				// DTYPE part2 = cache_TS_std_block[k + row_odd] * cache_query_std_block[k + col_odd];
				// DTYPE part12 = part1 /part2;

				// DTYPE half = (10 * query_length) - 10*(( 100*cache_Q[k] -  query_length * cache_TS_mean_block[k + row_odd] * cache_query_mean_block[k + col_odd] )) / (cache_TS_std_block[k + row_odd] * cache_query_std_block[k + col_odd]);
				// distance = 2 * half;

				//distance = calculate_dis(query_length,cache_TS_mean_block[k + row_odd],cache_query_mean_block[k + col_odd],(cache_TS_std_block[k + row_odd]+1),(cache_query_std_block[k + col_odd]+1),cache_Q[k]);	
				//distance = 0;
                distance = 2 * ((10 * query_length) - 10*(( 100*cache_Q[k] -  query_length * cache_TS_mean_block[k + row_odd] * cache_query_mean_block[k + col_odd] )) / (cache_TS_std_block[k + row_odd] * cache_query_std_block[k + col_odd]));
				//distance = (( scale_query) - (( cache_Q[k] -  scale_query * cache_TS_mean_block[k + row_odd] * cache_query_mean_block[k + col_odd] )) / (cache_TS_std_block[k + row_odd] * cache_query_std_block[k + col_odd]));
                //save result part
				cache_my_val_block[k]= distance;
				cache_my_idx_block[k]= row;
			}
			perfcounter_t point4 = perfcounter_get();
			calcuD[tasklet_id] += point4-point3;


				//DONE：要初始化一下内存里的
			mram_read(&result_minValue[row], cache_mram_val_block, sizeof(DTYPE) * memo_bound);
			mram_read(&result_minIndex[row], cache_mram_idx_block, sizeof(DTYPE) * memo_bound);
			for (uint32_t k = 0 + row_odd; k < bound; k++){
				//先取row的，来一遍从0开始的（row）比较	

				if(cache_my_val_block[k] < cache_mram_val_block[k])
				{	
					cache_mram_val_block[k] = cache_my_val_block[k];
					cache_mram_idx_block[k] = cache_my_idx_block[k] + current_diag;
				}
			}
			//放回去
			mram_write(cache_mram_val_block, &result_minValue[row] ,sizeof(DTYPE) * memo_bound);
			mram_write(cache_mram_idx_block, &result_minIndex[row] ,sizeof(DTYPE) * memo_bound);


			//然后再取一遍col（+ daig）后，再来一遍
			mram_read(&result_minValue[col], cache_mram_val_block, sizeof(DTYPE) * memo_bound);
			mram_read(&result_minIndex[col], cache_mram_idx_block, sizeof(DTYPE) * memo_bound);
			for (uint32_t k = 0 + col_odd; k < bound; k++){

				if(cache_my_val_block[k] < cache_mram_val_block[k])
				{
					cache_mram_val_block[k] = cache_my_val_block[k];
					cache_mram_idx_block[k] = cache_my_idx_block[k];
				}
			//update the row and col
				col ++;
				row ++;
			}
			//放回去
			DTYPE back_col = col - bound;
			mram_write(cache_mram_val_block, &result_minValue[back_col] ,sizeof(DTYPE) * memo_bound);
			mram_write(cache_mram_idx_block, &result_minIndex[back_col] ,sizeof(DTYPE) * memo_bound);

			perfcounter_t point5 = perfcounter_get();
			memsave[tasklet_id] += point5-point4;
		}
	}

BARRIER_INIT(my_barrier, NR_TASKLETS); //here we init the barrier to sync

int main() {
	
	perfcounter_t init_point = perfcounter_config(COUNT_CYCLES, false);

	//每个tasklet确定自己的ID
	int tasklet_id = me();
	if(tasklet_id == 0){ //id = 0的tasklet要重置一下mem
		mem_reset(); // Reset the heap
	}

	dataread[tasklet_id] = 0;
	calcuQ  [tasklet_id] = 0;
	calcuD  [tasklet_id] = 0;
	memsave [tasklet_id] = 0;
	total   [tasklet_id] = 0;

	//Input arguments,定义变量然后从inputargs里面取对应的赋值.
	DTYPE ts_size  = DPU_INPUT_ARGUMENTS.ts_length;
	DTYPE query_length  = DPU_INPUT_ARGUMENTS.query_length;
	DTYPE profilelength = ts_size - query_length ;
	DTYPE slice_per_dpu = DPU_INPUT_ARGUMENTS.slice_per_dpu;
	//slice_per_dpu = 8;

	DTYPE init_slice = profilelength / NR_TASKLETS;
	if (init_slice % 2) init_slice = init_slice + 1;
	DTYPE init_start = tasklet_id * init_slice;
	DTYPE init_end   = init_start + init_slice;

	//init the tmp result in mram
	__dma_aligned DTYPE cache_init_value_block[ELEM_IN_BLOCK];
	__dma_aligned DTYPE cache_init_index_block[ELEM_IN_BLOCK];
	for (int j = 0; j < ELEM_IN_BLOCK; j++)
	{
		cache_init_value_block[j]= INT32_MAX;
		// cache_init_index_block[j]= 0;
	}

	for (int i = init_start; i < init_end; i = i + ELEM_IN_BLOCK)
	{
		id[1] = cache_init_value_block[0];
		mram_write(cache_init_value_block, &result_minValue[i], ELEM_IN_BLOCK * sizeof(DTYPE));
		// mram_write(cache_init_index_block, &result_minIndex[i], ELEM_IN_BLOCK * sizeof(DTYPE));
	}

	id[0] = NR_TASKLETS; ///放进去看看

	perfcounter_t pre_point = perfcounter_get();
	
	//分block从里面拿diag进行计算
	
	DTYPE current_diag;
	//CHANGE:all in block no considering rest 
	// for(int i = 0 ; i < slice_per_dpu ; i += ELEM_IN_BLOCK){
	// 	DTYPE mpbound = (ELEM_IN_BLOCK > (slice_per_dpu - i)) ? slice_per_dpu - i : ELEM_IN_BLOCK;
	// 	mram_read(&diags[i], cache_diag_block , ELEM_IN_BLOCK * sizeof(DTYPE));
	// 	for(int j = 0; j < mpbound; j++){
	// 		current_diag = cache_diag_block[j];
	// 		// printf("diag is : %d\n",current_diag);
    //         barrier_wait(&my_barrier);
	// 		scrimp(tasklet_id, profilelength, current_diag, query_length);
    //         barrier_wait(&my_barrier);
	// 	}
	// }
		for(int j = 0; j < slice_per_dpu; j++){
			current_diag = diags[j];
			//printf("diag is : %d\n",current_diag);
            barrier_wait(&my_barrier);
			scrimp(tasklet_id, profilelength, current_diag, query_length);
            barrier_wait(&my_barrier);
		}
	printf("OK\n");
	perfcounter_t end_point = perfcounter_get();
	id[7] = end_point - init_point;
	total[tasklet_id] = end_point - init_point;
	
	if(tasklet_id == 0){
		uint64_t avg_total    = 0;	
		uint64_t avg_dataread = 0;
		uint64_t avg_calcuQ   = 0;
		uint64_t avg_calcuD   = 0;
		uint64_t avg_memsave  = 0;
		for(int i =0; i< NR_TASKLETS; i++){
			avg_total    = avg_total    + (total[0] / NR_TASKLETS);		
			avg_dataread = avg_dataread + (dataread[0]/ NR_TASKLETS);
			avg_calcuQ   = avg_calcuQ   + (calcuQ[0] / NR_TASKLETS);
			avg_calcuD   = avg_calcuD   + (calcuD[0] / NR_TASKLETS);	
			avg_memsave  = avg_memsave  + (memsave[0] / NR_TASKLETS);
		}
		printf("clock per sec:  %u  \n",CLOCKS_PER_SEC);
		printf("avg_total    :  %lu \n",avg_total);
		printf("avg_dataread :  %lu \n",avg_dataread);
		printf("avg_calcuQ   :  %lu \n",avg_calcuQ  );
		printf("avg_calcuD   :  %lu \n",avg_calcuD  );
		printf("avg_memsave  :  %lu \n",avg_memsave );
	}

	// perfcounter_t point1 = perfcounter_get();
	id[8]= dataread[0];
	id[9]= calcuQ[0];
	id[10]= calcuD[0];
	id[11]= memsave[0];
	// scrimp(tasklet_id, profilelength, 1, query_length);
	// perfcounter_t point2 = perfcounter_get();
	// id[9] = point2;
	// id[10] = point2 -point1;		
	return 0;
}